package mooc.vandy.java4android.calculator.logic;

//Keeps consistency between programs to have a
//method exists on all programs.
public interface OperationInterface {
    public String toString();
}
